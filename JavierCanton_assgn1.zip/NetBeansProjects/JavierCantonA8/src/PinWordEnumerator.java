/**
* Title: PinWordEnumerator.java
* Semester: COP3337  Summer 2020
* @author Javier Canton
*
* I affirm that this program is entirely my own work
* and none of it is the work of any other person.
*
* The PinWordEnumerator program is responsible for taking a user inputted
* PIN code and listing out the enumerations of the keypad encodings for the
* PIN. This will be done by creating a recursive method that will get each 
* PIN number's encoding and list them in an alphabetical order with the last 
* PIN number always being the first character changed in the sequence. The 
* method will continue this pattern until there are no repeated encodings found
* within the keypadEncodings method. The keypadEncodings method essentially 
* assigns a switch statement case to each PIN number and represents how the 
* enumerations will be printed on screen. They are based on a typical phone pad
* and each case will have a character array that contains the characters at 
* the specific PIN number location. A wrapper method is used to call on the 
* recursive method until the keypadEncodings method finishes with a returned
* null statement. 
* 
*/
import java.util.Scanner;

/**
 * Class PinWordEnumerator that takes user inputted number keypad coding 
 * and converts different enumerated encodings.
 */
public class PinWordEnumerator 
{
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter a pin number-> ");
        String num = scan.nextLine();
        System.out.println();
        System.out.printf("The keypad encodings for %s are:%n",num);        
        enumerateWords(num);
    }
    
    /**
     * This method is wrapper for the recursive method that enumerates all the 
       phone keypad encoding for a number.
       @param n a string representing the number.
     */
    public static void enumerateWords(String n)
    {
        /**
         * If statement calls on the recursive method to enumerate numbers of 
         * word until the keypadEncodings method returns a null statement.
         */
        if(n != null)
            enumerateWords(n, "");
    }
    
/**
 * This method returns a character array that contains all the possible
 * combinations from the keypad that the user inputted. 
 * @param n gets the case number for which we test for.
 * @return character array. 
 */
    static char[] keypadEncodings(int n) {
        switch (n) {
            case 0:
                return new char[] { ' ' }; //returns space
            case 1:
                return new char[] { '.' };//returns dot
            case 2:
            return new char[] { 'A', 'B', 'C' };//returns A, B, C
            case 3:
            return new char[] { 'D', 'E', 'F' };//returns D, E, F
            case 4:
            return new char[] { 'G', 'H', 'I' };//returns G, H, I
            case 5:
                return new char[] { 'J', 'K', 'L' };//returns J, K, L
            case 6:
                return new char[] { 'M', 'N', 'O' };//returns M, N, O
            case 7:
                return new char[] { 'P', 'Q', 'R', 'S' };//returns P, Q, R, S
            case 8:
                return new char[] { 'T', 'U', 'V' };//returns T, U, V
            case 9:
                return new char[] { 'W', 'X', 'Y', 'Z' };//returns W, X, Y, Z
        }
        //returns null statement
        return null;
    }
    
     /**
     * This method performs a recursive function that gets the text
     * from the user inputted pin. 
     * @param num represents the current number. 
     * @param text represents the text from the converted spelling.
     */
    static void enumerateWords(String num, String text) {
        if (num.length() == 0) {
            // base case that displays the text
            System.out.println(text);
        } 
        else {
            // finds the digit at 0th position
            int digit = num.charAt(0) - '0';
            
            //finds phone keys for each digit
            char letters[] = keypadEncodings(digit);
            if (letters != null) {
                //for loop goes through all possible keys
                for (int i = 0; i < letters.length; i++) {
                    /**
                     * This part of the method gets the current letter and
                     * appends it to text. The method then recursively calls 
                     * itself and ignores the first letter of the current 
                     * @num of the String. 
                     */
                    enumerateWords(num.substring(1), text + letters[i]);
                }
            }   
        }
    }
}

