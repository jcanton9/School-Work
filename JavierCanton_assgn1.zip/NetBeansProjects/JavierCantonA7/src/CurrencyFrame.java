/**
* Title: CurrencyFrame.java
* Semester: COP3337 Summer 2020
* @author Javier Canton
*
* I affirm that this program is entirely my own work
* and none of it is the work of any other person.
*
* The CurrencyFrame class is responsible for creating the UI of the 
* application. We do this by extending the JFrame for the class and 
* initializing private variables that act as ComboBoxes, Buttons, and Labels.
* We also set the Frame Width and Height of the application to an appropriate 
* fixture to look presentable for the user. The constructor initializes the 
* UI by setting up the ComboBoxes, the Button, and Labels. The bounds are also 
* set up in this stage in order for once again it to look presentable in the 
* final application. The ButtonListener class is used to call on the Converter
* method for when the button is clicked by the user. The converter method uses
* a switch statement which deals with the cases for which currency 1 is selected
* and has 2 if statements that execute depending on the second currency. The
* program also delivers two statements to the user if they do not follow 
* instructions properly. If the user inputs numbers that cannot be converted, 
* the program returns and error message and tells them to try again. If they try
* to convert the same currencies, then it returns an information message to 
* select different currencies. 
*/
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *Class that renders the UI of the application
 */
public class CurrencyFrame extends JFrame{
    
    private static final int FRAME_WIDTH = 450;
    private static final int FRAME_HEIGHT = 250;
    private JTextField textField;
    private JComboBox combo1;
    private JComboBox combo2;
    private JButton button;
    private JLabel resultLabel;
    private JLabel toLabel;
    
    //constructor initializes UI of application
    public CurrencyFrame(){
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setResizable(false); 
        
        //methods that initialize UI Control
        textField = new JTextField("Enter amount...");
        combo1 = new JComboBox();
        combo1.addItem("USD");
        combo1.addItem("EUR");
        combo1.addItem("GPB");
        combo2 = new JComboBox();
        combo2.addItem("USD");
        combo2.addItem("EUR");
        combo2.addItem("GPB");
        button = new JButton("Convert");
        resultLabel = new JLabel("Converted amount ...");
        toLabel = new JLabel("to");
        
        JPanel panel = new JPanel();
        add(panel, BorderLayout.CENTER);
        
        panel.setLayout(null);//panel layout is set to NULL
        panel.add(textField); textField.setBounds(20, 40, 150, 20);
        panel.add(combo1); combo1.setBounds(20, 80, 150, 20);
        panel.add(combo2); combo2.setBounds(210, 80, 150, 20);
        panel.add(button); button.setBounds(140, 140, 100, 30);
        panel.add(resultLabel); resultLabel.setBounds(210, 40, 150, 20);
        panel.add(toLabel); toLabel.setBounds(185, 80, 20, 20);
        
        button.addActionListener(new ButtonListener());
    }
    
    /**
     * This class implements the ActionListener to listen to 
     * click events from the button. 
     */
    class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            double amount;
            
            //try to get amount 
            try {
                amount = Double.parseDouble(textField.getText());
            }
            //catches any amount that is illegal
            catch(NumberFormatException ex) {
                //displays message for illegal numbers 
                JOptionPane.showMessageDialog
                (CurrencyFrame.this,
                "Illegal amount entered!",
                "Try Again.",
                JOptionPane.ERROR_MESSAGE);
                return;
            }
            //gets current and target currencies
            String curr1 = (String)combo1.getSelectedItem();
            String curr2 = (String)combo2.getSelectedItem();
            
            /**
             * If statement tests for currencies equal to one another
             * and gives user information statement if they are to input
             * different currency.
             */
            if(curr1.equals(curr2)){
                //displays information message
                JOptionPane.showMessageDialog
                (CurrencyFrame.this,
                "Please select different currencies!",
                "Try Again.",
                JOptionPane.INFORMATION_MESSAGE);
                
            }
            //sets the text of resultLabel to the result
            resultLabel.setText(convert(amount, curr1, curr2) + " " + curr2);

        }
    }
    
    /**
     * Method carries out the currency conversion.
     * @param amount represents amount input by user.
     * @param curr1 represents first currency.
     * @param curr2 represents second currency.
     * @return result as double floating point.
     */
    private double convert(double amount, String curr1, String curr2){
        
        /*
        * 1 EUR = 1.42 USD
        * 1 GPB = 1.64 USD
        * 1 GPB = 1.13 EUR
        */
        double result = 0;
        //switch statements for conversion of euros to other currencies
        switch (curr1) {
            case "EUR":
                //If selected dollars, converts euros to dollars
                if(curr2.equals("USD")){
                    result = amount * 1.42;
                }
                //Else if pounds, converts euros to pounds
                else if(curr2.equals("GPB")){
                    result = amount / 1.13;
                }   break;
            case "USD":
                //If selected euros, converts dollars to euros
                if(curr2.equals("EUR")){
                    result = amount / 1.42;
                }
                //Else if pounds, converts dollars to pounds
                else if(curr2.equals("GPB")){
                    result = amount / 1.64;
                }   break;
            case "GPB":
                //If selected euros, converts dollars to euros
                if(curr2.equals("EUR")){
                    result = amount * 1.13;
                }
                //Else if pounds, converts dollars to pounds
                else if(curr2.equals("USD")){
                    result = amount * 1.64;
                }   break;
            default:
                break;
        }
        return result;
    }
}
