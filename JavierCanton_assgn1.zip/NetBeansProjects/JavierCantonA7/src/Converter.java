/**
* Title: Converter.java
* Semester: COP3337 Summer 2020
* @author Javier Canton
*
* I affirm that this program is entirely my own work
* and none of it is the work of any other person.
*
* The Converter class for this program is used to initialize the Frame class
* for the application. It has methods that are used to create a new frame based
* on the CurrencyFrame class once it opens and initializes. It will also have
* methods that are used to close the application once the window is exited and
* set the frame to visible and make the title Currency Conversion. 
*/
import javax.swing.JFrame;

/**
 *Class that initializes the CurrencyFrame
 */
public class Converter {

    /**
     * Main method initializes frame
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //initializes frame
        JFrame frame = new CurrencyFrame();
        
        //exits application when frame closes
        frame.setDefaultCloseOperation
                (JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Currency Conversion");//sets the title
        frame.setVisible(true);//sets visibility to true
    }
    
}
