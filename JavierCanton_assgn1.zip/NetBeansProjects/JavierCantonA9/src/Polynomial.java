/**
* Title: Polynomial.java
* Semester: COP3337 Summer 2020
* @author Javier Canton
*
* I affirm that this program is entirely my own work
* and none of it is the work of any other person.
*
* In this program we are trying to create a linked list of terms of polynomials
* that are given to us through the tester class. We first create a Linked List
* that represents the terms of the polynomial. We then create a constructor 
* class that creates an empty polynomial. The second constructor will construct
* a polynomial that sets terms to an empty polynomial. Our add method is uses
* the concepts of Linked Lists to add terms to the List depending on if they 
* are the same term, greater, or less than a current term. Like terms get added,
* while a new term that is greater than the current term will be placed in front
* in the Linked List. If it is less than, the list will recognize to place it 
* to the rear of the List. The multiply method is responsible for being able
* to multiply the polynomial linked lists together in order to form a combined
* polynomial that prints. The print method will check to see if the term is 
* greater than or less than 0 to see if a " + " or " - " is inserted before 
* the term. This method only checks for every term that is less than the size
* of the List, since the first term should always be positive. 
* 
*/

import java.util.LinkedList;
import java.util.ListIterator;
/**
   A class to represent a polynomial.
*/
public class Polynomial {
    LinkedList<Term> terms;//Linked List terms that serves as polynomial

    /**
     * 
     * Constructs an empty polynomial.
     */
    public Polynomial() {
        //Sets terms to an empty polynomial.
        terms = new LinkedList<Term>();
    }

    /**
     * 
     * Constructs a new polynomial with the given term.
     * @param t the term to initialize the polynomial with
     */
    public Polynomial(Term t) {
        //Sets terms to an empty polynomial. 
        terms = new LinkedList<Term>();
        //adds t to terms based on what is initialized. 
        terms.add(t);
    }

    /**
     * 
     * Adds the polynomial such that the terms are in sorted order
     * from highest power to lowest.
     * @param p the polynomial to add
     */
    public void add(Polynomial p) {
        int index = 0;
        boolean added;

        Term currTerm;//creates a current term

        /**
         * 
         * Compare each newTerm to current term
         */
        for(Term newTerm : p.terms) {
            added = false;
            /**
             * 
             * As long as the newTerm is not added or we have more terms to
             * compare.
             */
            while(!added && index < terms.size()) {
                currTerm = terms.get(index);
                /**
                 * If statement checks for the terms being 
                 * compared are same power and adds them if
                 * they are.
                 */
                if(currTerm.getPower() == newTerm.getPower()) {
                    currTerm.addIfSamePower(newTerm);
                    added = true;
                }
                
                /**
                 * Else if statement checks to see if new term is greater
                 * than the current term. It will place it ahead of the 
                 * current term if that is the case.
                 */
                else if(newTerm.getPower() > currTerm.getPower()) {
                    terms.add(index, new Term(newTerm.getCoefficient(),
                            newTerm.getPower()));
                    added = true;
                }

                /**
                 * If both statements are false, then the next term is moved
                 * on to and the index is incremented. 
                 */
                index++;
            }
            
                /**
                 * 
                 * If the newTerm did not match any powers in existing or its 
                 * power is not in the range of the existing.
                 */
                if(!added)
                    terms.add(new Term(newTerm.getCoefficient(),
                            newTerm.getPower())); //add to end
        }
    }

    /**
     * 
     * Multiplies the given polynomial with this one and returns the result.
     * @param p the polynomial to multiply
     * @return this p
     */
    public Polynomial multiply(Polynomial p) {
        Polynomial ans = new Polynomial();
        
        //for loop multiplies polynomials from terms to ans.
        for(Term t1 : p.terms) {
            for(Term t2 : terms) {
                Term t3 = t1.multiply(t2);
                ans.add(new Polynomial(t3));
            }
        }
        return ans;
   }

    /**
     * 
     * Prints the polynomial "nicely" so that it reads
     * from highest term to lowest and doesn't have a
     * leading "+" if the first term is positive.
     */
    public void print() {
        String str = "";

        for(int i = 0; i < terms.size(); i++) {
            Term t = terms.get(i);
            //if statement chcecks term coefficient greater than 0
            if(t.getCoefficient() > 0) {
                //if i is not zero than add a plus sign before term
                if(i != 0)
                str += " + " ;
            }
            //else statement adds a minus abefore the term
            else {
                str += " - ";
            }
            str += t.toString();
        }
        System.out.print(str);
    }
}