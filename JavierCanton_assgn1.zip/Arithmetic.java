import java.util.*;
/*
This class provides the methods to verify and evaluate expressions if possible
*/
public class Arithmetic {

    private String exp;
    private char postexp[] = new char[250];
    private double value = 0;

    /**
     * Constructor for Arithmetic that sets string exp equal to string s.
     * @param s string that acts as expression string.
     */
    public Arithmetic(String s) {
        exp = s;
    }

    
    /**
     * This method is responsible for determining if the expression can be
     * converted into postfix. 
     * @return true if balanced or false it not. 
     */
    public boolean isBalance() {
        Stack<Character> stk = new Stack<Character>();
        char ch1;
        //Loops until expression length to verify the expression
        for (int i = 0; i < exp.length(); i++) {
            ch1 = exp.charAt(i);
            //If the characters are (, {, or [, then push the character.
            if (ch1 == '(' || ch1 == '{' || ch1 == '[') {
                stk.push(ch1);
            } 
            //If the characters are ), }, or ] then peform try method.
            else if (ch1 == ')' || ch1 == ']' || ch1 == '}' ) {
                //peek the second character and then test for matching chars.
                try 
                {
                    char ch2=stk.peek();
                    /*
                    if the characters are matching in anyway, such as(), 
                    then perform a pop.
                    */
                    if((ch1 == ')' && ch2=='(') || (ch1 == '}' && ch2=='{') 
                            ||(ch1 == ']' && ch2=='[')) {
                        stk.pop();
                    }
                    //Return false if the characters do not match. 
                    else
                    {
                        return false;
                    }
                } 
                /*
                If the expception e is caught then the expression is 
                automatically
                */
                catch (Exception e) {
                    return false;
                }
            }
        }
        //If the stack is empty then the expression is not balanced
        if (!stk.empty()) 
        {
            return false;
        } 
        //Else returns true and epression is balanced
        else 
        {
            return true;
        }
    }

    /**
     * This postfixExpression() method provides the framework to convert
     * an infixed expression to postfix.
     */
    public void postfixExpression() {
        int pi = -1;
        Stack<Character> sk = new Stack<Character>();
        char ch1, ch2;
        //Loop will continue until the expression length and convert each char. 
        for (int i = 0; i < exp.length(); i++) 
        {
            ch2 = exp.charAt(i);
            //If character 2 is at least 0 or at most 9 then postfix the char. 
            if ((ch2 >= '0' && ch2 <= '9') || ch2 == ' ')
                postexp[++pi] = exp.charAt(i);
           //If the character is a symbol then see if each condition is met
            else if (ch2 == '+' || ch2 == '-' || ch2 == '*' || ch2 == '/' 
                    || ch2 == '%') 
            {
                    if (sk.empty()) 
                    {
                        sk.push(ch2);
                    }
                    else 
                    {
                        ch1=sk.peek();
                        if(ch1 == '+' || ch1 == '-' || ch1 == '*' 
                                || ch1 == '/' || ch1 =='%')
                        {
                            if (ch2 > ch1) 
                            {
                                      sk.push(ch2);
                            }
                            else {

                                while (!sk.empty() && (ch1 = sk.pop()) != '(' &&
                                        ch1 != '['  && ch1 != '{' && ch1 >= ch2) 
                                {
                                    postexp[++pi] = ' ';
                                    postexp[++pi] = ch1;
                                                          }

                                sk.push(ch2);
                            }
                         }
                else
                sk.push(ch2);
                }
            }
            /*
            If the character is a parentheses/bracket then the condition 
            for each are checked.
            */
            else if (ch2 == '(' || ch2 == ')' || ch2 == '{' || ch2 == '}' 
                    || ch2 == '[' ||ch2 == ']') 
            {
                if (ch2 == '(' ||ch2 == '[' || ch2 == '{') {
                    sk.push(ch2);
                }
            else {                   
                    while (!sk.empty() && (ch1 = sk.pop()) != '(' && ch1 != '[' && ch1!='{' ) {
                        if (ch1 != ')') {
                        postexp[++pi] = ' ';
                        postexp[++pi] = ch1;
                        }

                    }
                }
            }
        }

        while (!sk.empty()) {
            postexp[++pi] = ' ';
            postexp[++pi] = sk.pop();
        }
        postexp[++pi] = '\0';
    }
    /**
     * This method returns the postfix expression in a string. 
     * @return the postfix expression.
     */
    public String getPostfix() {
        return new String(postexp);
    }
    /**
     * This method evaluates the postfix expression. 
     */
    public void evaluateRPN() {
        Stack<Double> sc = new Stack<Double>();
        char ch;
        String pExp =new String(postexp);
        ArrayList<String> postExpStack = new ArrayList<String>();
        postExpStack.addAll(Arrays.asList(pExp.trim().split("[ \t]+")));

        //This loop will run until the post expression size and evaluate it.
        for (int i = 0; i < postExpStack.size();i++) {
            String st = postExpStack.get(i);
            try{  
                sc.push(Double.parseDouble(st));  
            }
            catch(Exception ex){
                ch=st.charAt(0);
                if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%') 
                {
                    try{
                        double t1 = (double) (sc.pop());
                        double t2 = (double) (sc.pop());
                        //The switch statements perform arithmetic based on sign
                        switch (ch) {
                            case '+':
                                value = t2 + t1;
                                break;
                            case '-':
                                value = t2 - t1;
                                break;
                            case '*':
                                value = t2 * t1;
                                break;
                            case '%':
                                value = t2 % t1;
                                break;
                            case '/':
                                value = t2 / t1;
                                break;
                        }
                        sc.push((double) value);
                    }
                    catch(Exception e){
                        System.out.println("incorrect postfix expression");
                    }
                }
            }
        }
        try
        {
            value = sc.pop();
            if(!sc.empty())
            throw new Exception();
        }
        catch(Exception e2){
            System.out.print("");
        }
    }
    
    /**
     * This will get the result of the postfix expression.
     * @return the value of the result from the post fix expression. 
     */
    public double getResult() {
        return value;
    }
}