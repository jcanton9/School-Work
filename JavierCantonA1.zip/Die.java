/** 
 *  Title: Die 
 * Semester: COP3337 � Summer 2020
 * @author Javier Canton
 * 
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 * 
 *This program is responsible for creating the methods
 * needed to generate a Die that has 6 sides and has
 * each side randomly generated. 
 * There is also a method that simulates a die throw
 * and generates the face of the die based on the 
 * random generated throw.
 */

import java.util.Random;
/**
 * This class models a die that, when cast,
 * lands on a random face.
*/
public class Die {
    private Random generator;
    private int sides;

    /**
       Constructs a die with a given number of sides.
       @param s the number of sides, e.g., 6 for a normal die.
    */
    public Die(int s)
    {
       sides = s;
       generator = new Random();
    }

    /**
       Simulates a throw of the die.
       @return the face of the die.
    */
    public int cast()
    {
       return 1 + generator.nextInt(sides);
    }
}
