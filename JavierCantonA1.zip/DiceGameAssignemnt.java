/** 
 *  Title: DiceGameAssignment
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * 
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 * 
 * This is the main class for simulating a dice game that 
 * calls on the GameSimulator class and calls on the
 * getWinPercent() method to see how many times
 * the player wins in both game 1 and game 2. 
 */

/**
 * This program simulates the wins and losses for
 * two different games of dice.
 */
public class DiceGameAssignemnt {
 public static void main(String[] args) {
 
  GameSimulator simulator = new GameSimulator(6, 1000000);

  simulator.runSingleDieSimulation();
  System.out.println("Game #1 wins: " + simulator.getWinPercent());
  System.out.println("Expected: .51");

  simulator.runDoubleDieSimulation();
  System.out.println("Game #2 wins: " + simulator.getWinPercent());
  System.out.println("Expected: .49");
 }
}
