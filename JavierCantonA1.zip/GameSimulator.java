/** 
 *  Title: Game Simulator
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * 
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 * 
 *This program is responsible for simulating the wins 
 * and losses for two games of dice. This is done by
 * using the Die class to create two dice as variables.
 * 
 * Both dice games have a boolean function that is set
 * to false unless the dice rolls a 6 for the first game
 * or a double 6 in the second game in the number of tries.
 */

/**
   This program simulates the wins and losses for
   two different games of dice.
*/
public class GameSimulator
{
   private int tries;
   private Die d1, d2;
   private int wins;
   private int losses;

   /**
      Construct a simulator object for die games.
      @param numSides the number of sides on the die.
      @param numTries the number of times to run the simulation.
   */
   public GameSimulator(int numSides, int numTries)
   {
      d1 = new Die(numSides);
      d2 = new Die(numSides);
      tries = numTries;
   }

   /**
      Runs a single die simulation.
      One die is cast 4 times. If a six appears in those 4 casts,
      then wins is incremented, otherwise losses is incremented.
      Simulation is run according to the number of tries set.
   */
   //method implementation of SingleDieSimulation
   public void runSingleDieSimulation()
   {
   //Use to repeat number of tries
      for(int i = 0; i < tries; ++i) {
      //set boolean didWin as false
      boolean didWin = false;
      for (int j =0; j < 4; ++j) {
      //if die has six 
      if(d1.cast() == 6) {
       //sets didWin to true
       didWin = true;
      }
      }
      //if didWin set to true
      if(didWin == true) {
       //increment win count by 1
       wins++;
      }
      //otherwise
      else {
       //increment the losses by 1
       losses++;
      }
      }
   }

   /**
      Runs a double die simulation.
      A pair of dice are cast 24 times. If a double-six appears in
      those 24 casts, then wins is incremented, otherwise losses
      is incremented. The simulation is run according to the number
      of tries set.
   */
   //method implementation of DoubleDieSimulation
   public void runDoubleDieSimulation()
   {
      wins = 0;
      losses = 0;
      for(int i = 0; i < tries; ++i) {
       //set boolean didWin to false
       boolean didWin = false;
       //loop for 24 cast times
       for (int j = 0; j < 24; ++j){
        if((d1.cast() == 6)&&(d2.cast() == 6)) {
         didWin = true;
        }
       }
       //if didWin is true
       if (didWin == true) {
        //increment wins by 1
        ++wins;
       }
       //otherwise
       else {
        //increment losses by 1
        ++losses;
       }
      }
   }

   /**
      Returns the % of wins.
      @return the % of wins.
   */
   public double getWinPercent()
   {
      return (double)(wins) / (wins + losses);
   }

   /**
      Returns the number of wins.
      @return the number of wins.
   */
   public int getWins()
   {
      return wins;
   }

   /**
      Returns the number of losses.
      @return the number of losses.
   */
   public int getLosses()
   {
      return losses;
   }
}

