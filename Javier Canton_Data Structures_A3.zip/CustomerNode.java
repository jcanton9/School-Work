/**
 * This class is to be used with the Linked List to create
 * the nodes for the List. 
 */
public class CustomerNode {//Provides node for linked list
	Customer cust;
	CustomerNode next;
	
	CustomerNode (Customer cust){
		this.cust = cust;
		next = null;
	}
}
