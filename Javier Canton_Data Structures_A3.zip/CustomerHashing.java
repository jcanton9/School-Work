/**
 * This class is responsible for creating the HashTable and setting
 * up all the values that are obtained. It will check to see if a 
 * key can be removed if it exists. It will also call on the Customer
 * class to set it up with a bucketIndex value. 
 */
public class CustomerHashing {
    // hashTable array is used to store array of chains
    public CustomerNode[] hashTable;

    //The constructor CusomterHashing() will declare a hash table
    CustomerHashing() {
        hashTable = new CustomerNode[10000];
    }
    
    private int hashCode(String key) {
        int keyLength = key.length();
        String keyString = key.substring(keyLength - 4);
        return Integer.parseInt(keyString);
    }

    // Method to remove a given key and its information
    public Customer removeKey (String key) {
        //Hash function is applied to get the 
        int cell = hashCode(key);

        //We get the head of the chain here
        CustomerNode head = hashTable[cell];

        // Search for key in its chain
        CustomerNode prev = null;
        while (head != null) {
            //If the key is detected by the hash
            //Key will be equal to the head of the customer phone
            if (head.cust.phone.equals(key))
                break;

            //The chain continues if the key is not found
            prev = head;
            head = head.next;
        }

        //Returns null if the key is not there
        if (head == null)
            return null;

        //Will remove the key
        if (prev != null)
            prev.next = head.next;
        else
            hashTable[cell] = head.next;

        return head.cust;
    }

    //This method will return the key value
    public Customer get(String key) {
        //Head of the chain is found for the key
        int bucketIndex = hashCode(key);
        CustomerNode head = hashTable[bucketIndex];

        //The while continues until key is found
        while (head != null) {
            if (head.cust.phone.equals(key))
                return head.cust;
            head = head.next;
        }

        //returns null if the key is not found
        return null;
    }

    //This method adds a key value to the hash
    public void add(String key,Customer value) {

        int bucketIndex = hashCode(key);
        CustomerNode head = hashTable[bucketIndex];

        // Check if key is already present
        while (head != null) {
            if (head.cust.phone.equals(key)) {
                head.cust = value;
                return;
            }
            head = head.next;
        }

        // The key gets inserted in the chain
        head = hashTable[bucketIndex];
        CustomerNode newNode = new CustomerNode(value);
        //A newly created node is added to the cell
        newNode.next = head;
        hashTable[bucketIndex] = newNode;

    }
}
