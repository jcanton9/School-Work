/**
 * This class will get the data for the Customer such as
 * the name, address, and the phone. 
 */
public class Customer {//The data class
	String name, address, phone;
	
	Customer(String name, String address, String phone){
		this.name = name;
		this.address = address;
		this.phone = phone;
	}
}
