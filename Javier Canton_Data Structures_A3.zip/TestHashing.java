/**
 *This class is the testing method for using a Hash Table with chaining.
 *This method essentially sets a Customer Index ID to each customer and 
 *assigns each customer their own phone number. 
 */
public class TestHashing {

	public static void main(String[] args) {
		//declares a map for CustomerHashing
        CustomerHashing phonebook = new CustomerHashing();
        
        String phone1 = "9541234567";//each phone string sets the number
        //each customer gets assigned a Customer class
        Customer customer1 = new Customer("Name1", "Address1", phone1);
        String phone2 = "3051234567";
        Customer customer2 = new Customer("Name2", "Address2", phone2);
        String phone3 = "786123567";
        Customer customer3 = new Customer("Name3", "Address3", phone3);

        System.out.println("Adding Values in the phonebook : ");
        //Prints out the customer ID and the number
        System.out.println("This is "+ customer1 +" their number is "+phone1);
        phonebook.add(phone1, customer1);
        System.out.println("This is "+ customer2 +" their number is "+phone2);
        phonebook.add(phone2, customer2);
        System.out.println("This is "+ customer3 +" their number is "+phone3);
        phonebook.add(phone3, customer3);
       
        System.out.println("Getting value of "+phone2+" from map");
        Customer customer = phonebook.get(phone2);
        System.out.println(customer);
       
        System.out.println("\nRemoving "+phone2);
        phonebook.removeKey(phone2);

	}

}
