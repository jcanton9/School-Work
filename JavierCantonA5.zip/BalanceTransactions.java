/** 
 * Title: BalanceTransactions
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class gets an input from the user for the ledger text file, 
 *  the starting cash, and final cash.The text file has to be a file that 
 *  is available to be read within the program and will produce an error message 
 *  if the program cannot access it and prompt user for another file. Once the 
 *  user input is correct, the program will read the transaction file for 
 *  the transactions that occur and will calculate the starting cash the user inputs 
 *  and give a final estimated cash that the user must correctly guess. If it is wrong, 
 *  then it prints cash does not match expected and actual. If it is right, 
 *  then it will print the expected value matches with actual. 
 */
import java.util.*;
import java.io.*;

/**
 * Class that gets the transactions from a text file and calculates user inputs for the
 * text file, starting balance, and user calculated final balance to see if it matches 
 * with the program generated final balance. 
 */
public class BalanceTransactions{
	
	String fileName;
	double cashBegin;
	double cashFinal;
	Scanner infile = null;

	  
	/**
	 * Gets input from the user and sets the file input
	 * to get a correct file that is available in the program
	 * @param sc gets the user input from the keyboard. 
	 */
	public void getInputFromUser(Scanner sc)
	{
    	/**
    	 * The do method gets the name of the text file, but 
    	 * also prompts user to input readable file. 
    	 */
		do
	    {
			System.out.print(" Enter name of the Text File: "); //Prompt user for the name of the file
		    fileName = sc.nextLine();  // get the file name using Scanner
		    //sets the infile to the fileName	
		    try {
		    	infile = new Scanner(new File(fileName));
		    	} 
		    //gives user error message if file not found
		    catch (FileNotFoundException e) {
		    	System.out.println(e.getMessage());
		    	}
		    	
		    }
	    	while(infile == null);
	        
	      
	        //gets amount of cash at the beginning
	        System.out.print(" Amount of Cash at the Beginning of the Day before any transactions: ");
	        cashBegin = sc.nextDouble();
	      
	        //gets amount of cash at the end of the day
	        System.out.print(" Amount of Cash at the End of the Day after all transactions are complete: ");
	        cashFinal = sc.nextDouble();
	}
    /**
     * This method reads the transactions.txt file and applies it to the 
     * user inputs.
     * @throws FileNotFoundException if the file is not found.
     */
	public void processUserInput() throws FileNotFoundException
    {
        double amountOfCash;
        String typeOfTransaction; // P or R
        String invoiceNumber;
        
        Scanner fileReader = new Scanner(new File(fileName));
        //Reading data
        while(fileReader.hasNext())
        {
            String dataRead[] = fileReader.nextLine().split(" ");	      
            //Reading invoice number from text file
            invoiceNumber = dataRead[0];	          
            //Reading cash amount from text file
            amountOfCash = Double.valueOf(dataRead[1]);
            //Reading transaction type from text file
            typeOfTransaction = dataRead[2];	          
            //For Paid results subtracts amount to cashBegin
            if(typeOfTransaction.equalsIgnoreCase("P"))
            {
                cashBegin = cashBegin - amountOfCash;
            }
            //For Received results adds amount to cashBegin
            else
            {
                cashBegin = cashBegin + amountOfCash;
            }
        }
        System.out.println("\n\n Ledger Balance: " + cashBegin);
  
        //Compares ending balance that user inputs.
        if(cashBegin == cashBegin)
        {
            System.out.println("\n Actual amount matches with the expected value.... \n");
        }
        //If user inputs wrong end balance, then amount does not match. 
        else
        {
            System.out.println("\n Actual amount DOES NOT match with the expected value.... \n");
        }
         //Closing Scanner for file reader. 
        fileReader.close();
    }
  
    /**
     * Main method that gets the getInputUser() and processInputUser()
     * methods by using ledgers. 
     * @param args
     * @throws FileNotFoundException if there is no valid file found. 
     */
    public static void main(String[] args) throws FileNotFoundException {
    	BalanceTransactions ledgerObj = new BalanceTransactions();
         Scanner sc = new Scanner(System.in);
         ledgerObj.getInputFromUser(sc);
         sc.close(); // close Scanner
         
         ledgerObj.processUserInput();
         
    }
}

