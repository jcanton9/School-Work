import java.util.Scanner;
/** 
 * Title: RestroomSimulation
 * Semester: COP3337 – Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class runs a simulation of a restroom that can have
 *  up to 5 and 30 stalls based on the input of the user.
 *  An array wc is created that then has a number of index
 *  equal to the user input. The for loop then tests to place 
 *  individuals in stalls that should be one stall away from one 
 *  another until there is no possible way for the next occupant
 *  to be spaced away from the next when another occupant comes
 *  in. This is done by calling on the addOccupant method from the 
 *  Restroom Class. 
 */

/**
      Print diagrams of restroom stalls as they are occupied.
      The premise is that people generally prefer to maximize
      their distance from already occupied stalls, by occupying
      the middle of the longest sequence of unoccupied places.
*/
public class RestroomSimulation
{
   public static void main(String[] args)
   {
       /* This reads the input provided by user
        * using keyboard
        */
	  Scanner scan = new Scanner(System.in);
      System.out.println("Enter number of stalls between 5 and 30");
      //asks for user to input number of stalls between 5 and 30
      int STALLS = scan.nextInt();//variable STALLS  has value determined by user if inputting between 5 and 30
      
      while (!((STALLS >= 5) && (STALLS<= 30))) //This loop runs until user enters value between 5 and 30
      {
          System.out.println("Enter number of stalls between 5 and 30");
          STALLS = scan.nextInt();
      }


      Restroom wc = new Restroom(STALLS);//creates an array using the Restroom class as the type

      for (int i = 1; i <= STALLS; i++)//for loop adds occupants each time until number of STALLS is reached
      {
         wc.addOccupant();//adds occupant in array using the addOccupant() method
         System.out.println(wc.getStalls());//prints the result of addOccupant using getStalls() method
      }
   }
}