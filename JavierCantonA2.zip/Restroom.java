/** 
 * Title: Restroom
 * Semester: COP3337 – Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class makes a restroom that creates an array
 *  for stalls using the boolean type. There is then a 
 *  method that uses @param ns to create an array for the 
 *  number of stalls. The add occupant method creates
 *  an occupant in each stall that is added according to whether
 *  they are in the vicinity of one another. The last method is 
 *  responsible for the printing of whether the stall is occupied or
 *  not by using a boolean for loop to check if the condition is true
 *  or false. 
 */

/**
   A class that shows how restroom stalls are occupied.
*/

public class Restroom
{
   private boolean[] s; //array that signifies the stalls

   /**
      Constructs a restroom with a given number of stalls.
      @param ns the number of stalls
   */
   public Restroom(int ns)
   {
	   /*
	      Creates an array that uses number of stalls
	      inputed by the user or code as size of 
	      array.
	    */
	   s = new boolean[ns];
   }

   /*
      Adds an occupant in the middle of the longest sequence of
      unoccupied places. 
   */
   public void addOccupant()
   {
       int currOccupant = 0; //this variable is used for the current occupant (occupant 1, etc.)
       int totOccupant = 0;//this variable is used for the total occupants
       int temp1 = 0; //temporary variable 1 used to store temporary values
       int temp2 = 0; //temporary variable 2 used to store temporary values
       for (int i = 0; i < s.length + 1; i++)
       {
           if (i == s.length)//This if statement tests to see if the for loop has
           {
               if (temp1 > currOccupant)//if condition checks if temp1 is greater than currOccupant number
               {
            	   currOccupant = temp1;//sets currOccupant equal to temp1 value
            	   totOccupant = temp2;//sets totOccupant equal to temp2 value
               }
           }
           else if (temp1 == 0 && !s[i]) 
        	/*
           this if condition checks to see that temp1 equals zero and is not the current array 
           index value.
           */
           {
               temp2 = i;//sets temp2 value to the current i  value
               temp1++;//increments temp1  by 1
           } 
           else //condition runs if the other two are false
           {
               if (!s[i])//this condition checks if temp1 is not the index value
               {
                   temp1++;
               } 
               else//runs if the first conditon is false
               {
                   if (temp1 > currOccupant)//checks to see if temp1 is greater than currOccupant
                   {
                	   currOccupant = temp1;//sets currOccupant equal to temp1 value
                	   totOccupant = temp2;//sets totOccupant equal to temp2 value
                   }
                   temp1 = 0;//sets temp1 equal to zero
               }
           }
       }

       s[totOccupant + currOccupant / 2] = true;        
       /*
        * This statement tests to make sure that the array
        * of stalls (s) adds up the totOccupant and currOccupant to be 
        * divisible by 2 as an even element of s. 
        */
   }


   /*
      Gets a string describing the current stall occupation
      @return a string with _ for an empty stall and X for an occupied one
   */
   public String getStalls()
   {
      String stallOccupied = ""; //String variable stallOccupied that is used to print X or _  
      for(boolean a:s)      
    	  /*
           * This enhanced for loop tests the stalls array to
           * see if There is an occupant in the stall or not
           * and will print X for true or _ for false. It uses the boolean
           * a to and the array s to see if it is true or false.
           */
    	  stallOccupied += a?"X":"_";
      return stallOccupied;//@return stallOccupied X or _ depending on the condition
   }
}
