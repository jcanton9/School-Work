/** 
 * Title: RestroomTester2
 * Semester: COP3337 – Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class creates an array of size twelve and calls
 *  on the restroom class to print out the restroom stalls
 *  occupied based on the for loop. The stalls should show
 *  that there are certain spaces between each stall until they 
 *  are filled with occupants. There are also expected phases
 *  that show how the stalls should be filling out. 
 */

//HIDE
public class RestroomTester2
{
   public static void main(String[] args)
   {
      int STALLS = 12;
      Restroom wc = new Restroom(STALLS);
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: ______X_____");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: ___X__X_____");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: ___X__X__X__");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: _X_X__X__X__");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: _X_X_XX__X__");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: _X_X_XX_XX__");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: _X_X_XX_XX_X");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: XX_X_XX_XX_X");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: XXXX_XX_XX_X");
   }
}