/** 
 * Title: RestroomTester
 * Semester: COP3337 – Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This method creates an array of size twelve and calls
 *  on the restroom class to print out the restroom stalls
 *  occupied based on the for loop. The stalls should show
 *  that there are certain spaces between each stall until they 
 *  are filled with occupant based on how the expected states 
 *  should look like. 
 */

public class RestroomTester
{
   public static void main(String[] args)
   {
      int STALLS = 12;
      Restroom wc = new Restroom(STALLS);
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: ______X_____");
      wc.addOccupant();
      System.out.println(wc.getStalls());
      System.out.println("Expected: ___X__X_____");
   }
}