/** 
 * Title: BaseFormatter
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class formats a number by the base number that is
 *  stored in the n value. The base is declared as an integer value
 *  in the program firstly. The constructor then formats the base
 *  to be 2 if the base value falls out of the base range. The getBase()
 *  gets the base and sets it as the current base value. The base and number
 *  are then formatted into a string and returns it as a result. 
 */

/**
 *Class that formats the number as base n, where n
 *is any number between 2 and 36. 
 */
public class BaseFormatter implements NumberFormatter {

	int base;
	
	/**
	 * Formats base to equal 2 if out of range.
	 * @param baseFormat sets the format of the base.
	 */
	public BaseFormatter(int baseFormat) {
		base = baseFormat;
		//if values out of range 2-36 inclusive are given, set default to 2
		if(base < 2 || base > 36) {
			base = 2;
		}
	}
	/**
	 * Converts the base and number result into a
	 * String.
	 * @param n gets the number to be formatted.
	 * @returns result of BaseFormatter.
	 */
	@Override
	public String format(int n) {
		//converts n and base into a string
		String result = Integer.toString(n, base); 
		//returns result
		return result;
	}
	
	/**
	 * Gets the base number.
	 * @param base is set to the base number obtained.
	 * @return the base number.
	 */
	int getBase(int base) {
		//sets the base equal to the base obtained
		this.base = base;
		//returns the base value
		return base;
	}

}