/** 
 * Title: AccountingFormatter
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class formats a number based on if it is a negative
 *  value. This is done by firstly setting the result of the 
 *  number to equal its absolute value. An if-else checks to see
 *  if the number is less than 0 to put parentheses around the 
 *  resulting number.
 */

/**
 * Formats negative number with parenthesis and sets it equal
 * to its absolute value. 
 */
public class AccountingFormatter implements NumberFormatter {

	/**
	 * Formats number to its absolute value
	 * and puts parentheses if the number is less than 0.
	 * @param n gets the current number.
	 * @return the result in parentheses if negative, else normal result.
	 */
	@Override
	public String format(int n) {
		//sets result to value of integer at absolute value
		String result = String.valueOf(Math.abs(n));
		
		//If number is less than 0 return result in parentheses
		if (n < 0) {
			return "(" + result + ")";
		}
		//Else return result
		else {
			return result;
		}
	}

}
