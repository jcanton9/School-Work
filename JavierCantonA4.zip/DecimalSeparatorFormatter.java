/** 
 * Title: DecimalSeparatorFormatter
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class formats a number by decimal separators.
 *  If a number has more than 3 digits, it will separate
 *  every 3 digits by commas. This is done by formatting the 
 *  String to print the number in decimal separator format by
 *  putting a comma between the %","d method. 
 */

/**
 * Class that formats number with Decimal Separators.
 */
public class DecimalSeparatorFormatter implements NumberFormatter{
	
	/**
	 * Formats number with decimal separator.
	 * @param n is formatted with decimal separators.
	 * @return the decimal formatted number.
	 */
    @Override
    public String format(int n) {
    	//String decimal formats number n with decimal separators
    	String decimalFormat = String.format("%,d", n);
    	//returns decimalFormat
    	return decimalFormat;
    }
    
}
