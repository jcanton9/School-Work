/** 
 * Title: NumberFormatter
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This interface is used in the code to set how String format
 *  declaration should act like. The String format method will
 *  always have @param n to get the number needed for the format
 *  and convert it into a String and return a String result.  
 */

/**
 *Interface that creates a formatted String
 *that is expected to be overwritten.
 *@param n will be used to get the number.
 *It will also be formatted as a String.
 *A return value should be a String.
 */
public interface NumberFormatter {
	//formats method declaration
	String format (int n);
}
