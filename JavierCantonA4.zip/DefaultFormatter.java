/** 
 * Title: DefaultFormatter
 * Semester: COP3337 � Summer 2020 
 * @author Javier Canton
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 *  
 *  This class formats a number in the usual manner and 
 *  does not give it special instructions to print it in
 *  any certain way. 
 */

/**
 *Class that formats number in usual way. It implements
 *the NumberFormatter interface to have defined in the code.
 */
public class DefaultFormatter implements NumberFormatter {
	
	/**
	 * Formats number in default manner.
	 * @param n gets the number.
	 * @return the result as a string.
	 */
	@Override
	public String format(int n) {
		//converts n into String
		String result = Integer.toString(n);
		//returns the result
		return result;
	}
	
}
