/**
* Title: DirectoryComparator.java
* Semester: COP3337 – Summer 2020
* @author Javier Canton
*
* I affirm that this program is entirely my own work
* and none of it is the work of any other person.
*
* 
* This class is responsible for being able to sort directories in a sorted order
* that is numerically, then alphabetically sorted. This is done by creating a
* method that compares two directories as strings. The directories are then
* sorted into a String token array for each directory that separates them into 
* an index containing the String value for index 0 and the integer value for 
* index 1. Directory 1 is sorted into token1 and Directory 2 is sorted 
* into token2. An if statement then tests to see if the token arrays at index 
* zero have the same value. For example if, dir1 is set as dir12 and dir2 is set
* as dir1, then the if statement executes and returns the integer values of 12 
* minus 2. The Collections.sort method in the main method will recognize that it
* is a positive return value and swap the two values. If instead dir12 was 
* compared with quiz12 then the else statement executes and compares dir 12 
* with quiz12 and sorts them based on hexadecimal value. 
* 
*/
import java.util.Comparator;

/**
 *This class is used to sort directories in numerical, then alphabetical order.
 */
public class DirectoryComparator implements Comparator<String> {
    
    /**
     * Method compares two strings and sorts them based on if the string is 
     * equal and then the integer value if they are the same name strings.
     * @param dir1 is the first string compared.
     * @param dir2 is the second string compared.
     * @return dir1 - dir2 value if index values are equal, else does a 
     * compareTo method for dir1 and dir2. 
     */
    @Override
    public int compare(String dir1, String dir2) {
        
        /**
         * Sets each directory to String tokens that splits the directories
         * by the String and then by the integer.
         */
        String tokens1[] = dir1.split("(?<=\\D)(?=\\d)");
        String tokens2[] =  dir2.split("(?<=\\D)(?=\\d)");
        
        /**
         * If statement checks to see if first index of tokens1 equals tokens2 
         * value. 
         * @return value of directory 1 number minus directory 2 value.
         */
        if(tokens1[0].equals(tokens2[0])){
            return Integer.parseInt(tokens1[1]) - Integer.parseInt(tokens2[1]);
        }
        //Else returns dir1 compareTo method to dir2
        else {
            return dir1.compareTo(dir2);
        }
                
    }
}





















