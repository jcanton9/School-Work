/** 
 *  Title: WorldClock
 * Semester: COP3337 – Summer 2020 
 * @author Javier Canton
 * 
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 * 
 * This class is a subclass of Clock and extends it. 
 * The WorldClock is responsible for being able to set a time zone
 * offset that can change the current time to the corresponding
 * offset time zone that the user or program sets it to. The private
 * offsetTime integer is declared in order for the program to store
 * a value in that variable the WorldClock class has a parameter offset
 * that stores the value of offsetTime depending on the ClockDemo value.
 * The getHours() method overrides the Clock getHours() method by changing 
 * the current hour to plus the offset that is set in the ClockDemo class.
 * This is done by adding the offsetTime value to hour and checking to make
 * sure that the value added does not exceed 24 hours or is less than 0. 
 */

/**
 * PART II.
 * Provide a subclass of Clock named WorldClock whose constructor
 * accepts a time offset. For example, if you live in California,
 * a new WorldClock(3) should show the time in New York, three
 * time zones ahead. You should not override getTime. It then
 * returns the Integer as a string. 
 */
public class WorldClock extends Clock
{
   // Your work goes here
   private int offsetTime;
   
   /**
    * Constructs World Clock with 
    * @param offset with Time Zone offset
    */
   public WorldClock(int offset) {
	   this.offsetTime = offset;
   }
   
   /**
    * gets hours after applying offset
    * @return hours of current time in string
    * hour should add the offset here
   */
   @Override
   public String getHours()
   {
      //gets current hour
	   int hour = Integer.parseInt(super.getHours());
	   hour += offsetTime;
	   //tests to see if hour is greater than 24
	   if (hour > 24)
	   {
		   //subtracts 24 from hour
		   hour = hour - 24;
	   }
	   //tests to see if hour is less than 0
	   else if (hour < 0) {
		   //adds 24 to hour
		   hour = hour + 24;
	   }
	   //converts to String
	   return Integer.toString(hour);
	   
   }
}
