/**
 * In the SortingTester class we will create an array that is 
 * unsorted and print it to display it unsorted. Once that is 
 * done we will then call on the mergeSort method to sort the
 * array in numerical order and then print the sorted array. 
 *
 */
public class SortingTester {

	public static void main(String[] args) {
		
		//declare the unsorted array and print it
		int[]array = {45, 202, 4, 11, 65, 30};
		System.out.println("Initial Array is: ");
		MergeSort.printArray(array);
		
		//sort the array by calling on mergeSort method
		array = MergeSort.mergeSort(array);
		System.out.println("The Sorted Array is: ");
		MergeSort.printArray(array);
		

	}

}
