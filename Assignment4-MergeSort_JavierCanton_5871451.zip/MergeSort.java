/**
 * This class will perform the merge sort method.
 * It will first divide up the initial array into 
 * a left and right side. It will then fill those
 * arrays through certain conditions applied. Recursive
 * functions are declared for both those arrays in order
 * to return the sorted values correctly by then calling
 * on the merge method to return the array together. It will
 * continue to divide an conquer until the array is sorted 
 * correctly.  
 *
 */
public class MergeSort {
	
	public static void printArray(int [] array) {
		
		for(int i : array) {
			System.out.print(i + " ");
		}
		System.out.println();
	}
	
	public static int[] mergeSort(int[] array) {
		
		if (array.length <= 1) {
			return array;
		}
		int middle = array.length / 2; //Middle cuts array in half
		int[] leftSide = new int[middle];//creates array for left side
		int[] rightSide;//declared as right side values of array
		
		//Sets the right side value depending on array length
		if(array.length % 2 == 0) {
			rightSide = new int [middle];
		} else {
			rightSide = new int [middle + 1];
		}
		
		//populates the left side array
		for(int i = 0; i < middle; i++) {
			leftSide[i] = array[i];
		}
		
		//populates the right side array
		for(int j = 0; j < rightSide.length; j++) {
			rightSide[j] = array[middle + j];
		}
		
		//declare the final array with same length as original
		int[] finalArray = new int[array.length];
		
		leftSide = mergeSort(leftSide);//recursive call for leftSide array
		rightSide = mergeSort(rightSide);//recursive call for rightSide array
		
		/*
		 * The final array is equal to the merged array of the left side and right
		 * side arrays. 
		 */

		finalArray =  Merge.merge(leftSide,rightSide);
		return finalArray;
	}
	
	
}
