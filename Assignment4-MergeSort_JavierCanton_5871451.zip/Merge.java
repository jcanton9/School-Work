/**
 * This class is responsible for merging the two arrays
 * back together into a resulting array after the process of
 * the mergeSort method has occurred. We
 *
 */
public class Merge {
	//method will merge the left side and right side arrays
	public static int[] merge(int[] leftSide, int[]rightSide) {
		int[] finalArray = new int [leftSide.length + rightSide.length];//declares new final array
		
		int leftPntr, rightPntr, finalPntr;//declares pointer values for each array
		leftPntr = rightPntr = finalPntr = 0;
		
		/*
		 * As elements are still in either array the loop continues
		 * until the final array is filled and the other arrays are empty.
		 */
		while((leftPntr < leftSide.length) || (rightPntr < rightSide.length)) {
			//Will check if elements are in the right side and left side arrays
			if((leftPntr < leftSide.length) && (rightPntr < rightSide.length)) {
				
				if(leftSide[leftPntr] < rightSide[rightPntr]) {
					finalArray[finalPntr++] = leftSide[leftPntr++];
				} else {
					finalArray[finalPntr++] = rightSide[rightPntr++];				}
			}
			/*
			 * This method will only take elements in left array and place them in the final array
			 * if and only if they are in the leftSide array. It will increment final array 
			 * and left side pointer.
			 */
			else if(leftPntr < leftSide.length) {
				finalArray[finalPntr++] = leftSide[leftPntr++];
			}
			
			/*
			 * This method will only take elements in right array and place them in the final array
			 * if and only if they are in the rightSide array. 
			 * It will increment final array and right side pointer.
			 */
			else if(rightPntr < rightSide.length) {
				finalArray[finalPntr++] = rightSide[rightPntr++];
			}
		}
		return finalArray;
	}
}
