/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Default;

/**
 * This class creates the actual array needed to be sorted and
 * calls on the QuickSort class to perform the function. 
 */
public class Tester {
    public static void main(String[] args) {
        
        int[] array = {57,99,33,22,61};
        
        QuickSort quicksort = new QuickSort(array);
        quicksort.sort();
        quicksort.showArray();
    }
    
}




