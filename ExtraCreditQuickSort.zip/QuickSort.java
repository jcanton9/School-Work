package Default;

/**
 * QuickSort is a very similar algorithm to MergeSort because it is a 
 * divide and conquer algorithm. It picks an element that becomes the 
 * pivot and will partition the array that is picked(usually left or right
 * side). The running time of the QuickSort algorithm can depend on the 
 * partitions within the code. We could potentially see that quicksort may run
 * at the running time of O(n^2). The reason for this is because the partitions 
 * could be unbalanced and cause the constant along with the recursive call of 
 * each element to process each subproblem. In terms of the best case running 
 * time, it will run at O(n log base 2 n). The reason for this faster running 
 * time is because of the partitions being evenly balanced with the sizes being 
 * equal or within 1 of each other, or the subarray has an odd number of 
 * elements with the pivot in the middle of the partition. Usually the QuickSort
 * on average runs on the same runtime as the best case scenario, since there
 * will most likely be some balanced partitions within the subproblem that will 
 * not increase the subproblem size. 
 */

//The class performs the quicksorting of an array
public class QuickSort {
    
    private int [] nums;//initializes an array of numbers
    
    //Initializes the values
    public QuickSort(int[] nums){
        this.nums = nums;
    }
    
    //Calls on the quicksort to sort the values
    public void sort(){
        quicksort(0, nums.length - 1);
    }
    
    //Will print the array in a sorted order
    public void showArray() {
        for(int i = 0; i < nums.length; i++) {
            System.out.print(nums[i] + " ");
        }
    }
    
    //does the actual quicksort of the array
    private void quicksort(int low, int high){
        
        if(low >= high){
            return;
        }
        
        int pivot = partition (low, high);
        quicksort(low, pivot - 1);
        quicksort(pivot + 1, high);
    }
    
    //creates the partition for the quicksort algorithm
    public int partition(int low, int high) {
        int pivotIndex = (low + high)/2;
        swap(pivotIndex,high);
        
        int i = low;
        
        //Will run until the values are sorted in the correct indexes
        for(int j= low; j < high; j++) {
            //Checks if the j index is less than or equal to high index
            if((nums[j]) <= nums[high]) {
                swap(i,j);
                i++;
            }
        }
        swap(i,high);
        
        return i;
    }
    
    /**
     * Will perform a basic swap of numbers in the arrays
     * and exchange the numbers should we perform a swap
     * @param i represents the lower value.
     * @param j represents the higher value.
     */
    public void swap(int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
    
}










