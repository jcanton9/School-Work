/*
 * Javier Canton 5871451
 * COP 3530 RVC
 * RPN.Java
 * FIU Fall 2020
 */ 

//This class calls on Arithmetic 
public class RPN {
    /*
     * The main method calls on Arithmetic to create a tree and 
     * evaluate a notation
     */
    public static void main(String[] args) {
        // Read in the expression and build the tree.
        System.out.println("\nType a fully parenthesized expression " +
                           "using a..z,+,-,*,/ " + "This program will not"
                + "accept numbers");
        
        Arithmetic tree = new Arithmetic();
        tree.read();
        
        // Output it using all three types of notation.
        System.out.println("\n* The infix notation is:");
        tree.inorderPrint();
        System.out.print("\n\n* The prefix notation is:\n");
        tree.preorderPrint();
        System.out.print("\n\n* The postfix notation is:");
        tree.postorderPrint();
        System.out.println();
    }
}
