/*
 * Javier Canton 5871451
 * COP 3530 RVC
 * Arithmetic.Java
 * FIU Fall 2020
 */ 

import java.util.*;

/**
 * Arithmetic - will create a binary tree that is an Expression Tree. This will
 * allow for the user created expressions to be processed by each method of
 * either infix notation, prefix notation, or postfix notation. The print 
 * methods will call on each of these methods depending on the RPN call of 
 * which method is printed. A recursive call is done through the expression 
 * tree.
 */
public class Arithmetic {
    private class Node {
        private char contents;   
        private Node left;       
        private Node right;      
        
        /* 
         * isLeaf() - checks if each node is part of the tree. 
         */
        private boolean isLeaf() {
            return (left == null && right == null);
        }
    }
    
    private Node root;
    private Scanner in;
    
    public Arithmetic() {
        root = null;
        in = new Scanner(System.in);
    }
    
    /**
     * inorderPrint - uses infix notation to print the expression tree.
     * It calls inorderNotation to perform a recursive inorder traversal.
     */
    public void inorderPrint() {
        if (root != null) {
            inorderNotation((root));
        }
    }
    
    /*
     * inorderNotation - uses infix notation to print the (sub)tree
     * with the specified root. The left and right trees will print
     * the contents based on order of operation similar as an Expression 
     * Tree.
     */
    private static void inorderNotation(Node root) {
        if (root.isLeaf())
            System.out.print(root.contents);
        else {
            // internal node - an operator
            System.out.print("(");
            inorderNotation(root.left);
            System.out.print(" " + root.contents + " ");
            inorderNotation(root.right);
            System.out.print(")");
        }
    }
    
    /**
     * preorderPrint - uses prefix notation to print the expression tree.
     * It calls preorderNotation to perform a recursive preorder traversal.
     */
    public void preorderPrint() {
        if (root != null) {
            preorderNotation(root);
        }
    }
    
    /*
     * preorderPrintTree - The prefix notation will be printed
     * by having a call from the preorderPrint() to have the 
     * the conversion occur.
     */
    private static void preorderNotation(Node root) {
        if (root.isLeaf()) {
            System.out.print(root.contents);
        } else {
            //These cases will check for the operands
            switch (root.contents) {
                case '+':
                    System.out.print("add"); 
                    break;
                case '-':
                    System.out.print("subtract"); 
                    break;
                case '*':
                    System.out.print("multiply"); 
                    break;
                case '/':
                    System.out.print("divide"); 
                    break;
            }
            
            // then the left and right subtrees
            System.out.print("(");
            preorderNotation(root.left);
            System.out.print(", ");
            preorderNotation(root.right);
            System.out.print(")");
        }
    }
    
    /**
     * postorderPrint - uses postfix notation to print the expression tree.
     * It calls postorderNotation to perform a recursive postorder traversal.
     */
    public void postorderPrint() {
        if (root != null) {
            postorderNotation(root, 0);
        }
    }
    
    /*
     * postorderPrintTree - uses postfix notation to print the
     * expression tree that has the specified node as its root.  It
     * prints the tree by performing a recursive postorder traversal.
     * The margin argument helps to align the output properly.
     */
    private static void postorderNotation(Node root, int margin) {
        if (root.isLeaf()) {
            printMargin(margin);
            System.out.print(root.contents + "  ");
        } else {
            postorderNotation(root.left, margin + 1);
            postorderNotation(root.right, margin + 1);
            
            printMargin(margin);
            switch (root.contents) {
                case '+':
                    System.out.print("add above"); 
                    break;
                case '-':
                    System.out.print("subtract above"); 
                    break;
                case '*':
                    System.out.print("multiply above"); 
                    break;
                case '/':
                    System.out.print("divide above"); 
                    break;
            }
        }
    }
    
    /**
     * printMargin - used to print leading spaces when outputting
     * expressions in postfix notation
     */
    private static void printMargin(int margin) {
        System.out.println();
        for (int i = 1; i <= margin; i++) {
            System.out.print("    ");
        }
    }
    
    /**
     * readExpression - parses the user entered expression.  It
     * calls readTree to recursively process the expression.
     */
    public void read() {
        root = readTree();
    }
    
    /*
     * readTree - The arithmetic of the user is read in this method through the
     * tree expression that was created in this class. The roots are returned.
     */
    private Node readTree() {
        Node nd = new Node();
        
        // get next non-whitespace char
        char c = in.findInLine("(\\S)").charAt(0);
        if ((c >= 'a') && (c <='z')) {
            //The if checks to see if it's characters a-z and looks at nodes
            nd.contents = c;
            nd.left = null;
            nd.right = null;
        } else if (c == '(') {
            //Else it checks the parentheses in its contents through the nodes
            nd.left = readTree();
            nd.contents = in.findInLine("(\\S)").charAt(0);
            nd.right = readTree();
            c = in.findInLine("(\\S)").charAt(0);
            if (c != ')') {
                System.out.print("EXPECTED ) - } ASSUMED...");
            }
        } else {
            System.out.print("EXPECTED ( - CAN'T PARSE");
            System.exit(1);
        }
        
        return nd;
    }
}